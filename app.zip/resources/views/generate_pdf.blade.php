<!DOCTYPE html>
<html>
<head>
    <title>Generate Pdf</title>
</head>
<body>
  <h1>{{ $heading}}</h1>
  <div>
     <p>{{$content}}</p>
  </div>
</body>
</html>