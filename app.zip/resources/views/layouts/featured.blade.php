@if(isset($status))
    @if($status == 1)
        <span >Yes</span>
        @else
        <span >No</span>
    @endif
@endif