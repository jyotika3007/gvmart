@extends('layouts.front.app')

@section('content')



@endsection