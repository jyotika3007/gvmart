<?php

namespace App\Shop\Teams;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{

}
