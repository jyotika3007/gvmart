<?php

namespace App\Shop\Newsletter;

use Illuminate\Database\Eloquent\Model;

class Newsletter extends Model
{
    //
}
