<?php

namespace App\Shop\Tools;

use Illuminate\Http\UploadedFile;

trait UploadableTrait
{
    
}
