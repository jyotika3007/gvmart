<?php

namespace App\Shop;

use Illuminate\Database\Eloquent\Model;

class RegisteredShop extends Model
{
    //
}
