<?php

namespace App\Shop;

use Illuminate\Database\Eloquent\Model;

class EmailVerification extends Model
{
    //
}
