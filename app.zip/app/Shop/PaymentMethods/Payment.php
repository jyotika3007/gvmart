<?php

namespace App\Shop\PaymentMethods;

class Payment
{
    }
