<?php

namespace App\Shop\Cart;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    //
}
