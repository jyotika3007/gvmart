<?php

namespace App\Shop\BlogReviews;

use Illuminate\Database\Eloquent\Model;

class BlogReview extends Model
{
    //
}
