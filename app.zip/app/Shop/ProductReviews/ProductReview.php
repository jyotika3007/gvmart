<?php

namespace App\Shop\ProductReviews;

use Illuminate\Database\Eloquent\Model;

class ProductReview extends Model
{
    //
}
