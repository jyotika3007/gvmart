<?php

namespace App\Shop;

use Illuminate\Database\Eloquent\Model;

class ProductSize extends Model
{
    //
}
