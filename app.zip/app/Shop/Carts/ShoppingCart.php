<?php

namespace App\Shop\Carts;


class ShoppingCart extends Cart
{
    
}
