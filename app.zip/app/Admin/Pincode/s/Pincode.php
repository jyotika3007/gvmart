<?php

namespace App\Admin\Pincode\s;

use Illuminate\Database\Eloquent\Model;

class Pincode extends Model
{
    //
}
