<?php

namespace App\Shop\Offers;

use Illuminate\Database\Eloquent\Model;

class Offer extends Model
{
    //
}
